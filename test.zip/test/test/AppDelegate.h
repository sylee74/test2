//
//  AppDelegate.h
//  test
//
//  Created by 이상윤 on 2017. 9. 19..
//  Copyright © 2017년 sylee. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

